package com.task_1.Kaiburr_karthik;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KaiburrKarthikApplicationTests {

	@Test
	void contextLoads() {
	}

}

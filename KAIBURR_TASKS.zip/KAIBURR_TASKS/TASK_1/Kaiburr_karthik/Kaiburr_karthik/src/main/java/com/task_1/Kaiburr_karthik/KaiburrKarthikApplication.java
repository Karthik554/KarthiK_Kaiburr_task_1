package com.task_1.Kaiburr_karthik;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@SpringBootApplication
@EnableMongoRepositories
public class KaiburrKarthikApplication {  // ✅ Changed class name to match file name
	public static void main(String[] args) {
		SpringApplication.run(KaiburrKarthikApplication.class, args);
	}
}
